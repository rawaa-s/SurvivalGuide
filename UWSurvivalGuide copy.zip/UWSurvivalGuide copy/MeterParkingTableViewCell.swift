//
//  MeterParkingTableViewCell.swift
//  UWSurvivalGuide
//
//  Created by Rawaa alshafeai
//  Copyright © Rawaa alshafeai. All rights reserved.
//

import UIKit

class MeterParkingTableViewCell: UITableViewCell {
    
    
    //Meter Parking outlets
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    //Permit Parking outlets
    
    @IBOutlet weak var parkingLotLabel: UILabel!
    
    //VisitorParking outlets
    
    @IBOutlet weak var visitorParkingLabel: UILabel!
    @IBOutlet weak var visitorParkingNote: UILabel!

}
