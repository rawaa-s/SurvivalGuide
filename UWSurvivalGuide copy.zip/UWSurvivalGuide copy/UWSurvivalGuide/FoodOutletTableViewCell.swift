//
//  FoodOutletTableViewCell.swift
//  UWSurvivalGuide
//
//  Created by Rawaa alshafeai
//  Copyright © Rawaa alshafeai. All rights reserved.
//

import Foundation
import UIKit


class FoodOutletTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var directionButton: UIButton!
    @IBOutlet weak var mealImage: UIImageView!
    
    @IBOutlet weak var informationLabel: UILabel!
    
    
}
