//
//  README.swift
//  UWSurvivalGuide
//
//  Created by Rawaa Alshafeai  on 30/05/1440 AH.
//  Copyright © Rawaa Alshafeai . All rights reserved.
//

//The final self-decide project from Udacity
//## Requirements

//- Xcode 10.1
//- Swift 4.0
//- rawaa3949@gmail.com

//## Building

//- Open the .xcodeproj file and run!

//The libraries you used in this project :
//1- UIkit
//2- foundation
//3-Mapkit
//4-coredata

//UWSurvivalGuide is made based on the API from University of Waterloo.
//There are 3 sections, which are News, Events, and Food.
//
//![f3ee4a4c-2da8-493b-aca2-3ed25abcfa06](https://cloud.githubusercontent.com/assets/16344019/17907145/6cb1517e-6948-11e6-8c33-8ed3e5163176.png)
//![14c4e23c-1af0-4e79-bd91-cfd92c32f94f](https://cloud.githubusercontent.com/assets/16344019/17907156/75b55cfc-6948-11e6-8c28-888e6ef58567.png)
//
//
//##In News section, users can:
//
//1. View news in list style, where each page has 5 news with News title, news image(if there is one, otherwise the campus bubble will replace it's position), and a short beginning words from tne news.
//2. click the next page or previous page to change the page, or enter the page they want to go.
//3. After entering a news, the time of the news being published and updated will show up. And of course the news itself. The full size image too.
//4. The News section has self-refresh function. After user quit the app after 3 hours, the News section will refresh itself when users go back to the app.
//
//##In Events section, users can:
//
//1. see all the events posted by University of Waterloo, either on campus or off campus. In the lists, only event type, name and time are included.
//2. when user select an event, the event description will show up too.
//3. If users think the event's info is not sufficient, they can click the link button to see the original link on safari.
//4. There is a location button to help user to find the location on map.
//5. If users are interested in some events, they can click the "star" button to put it into the ExpectedEvent list. the expected event will have yellow star among all the event list.
//6. The event list is also searchable.
//7. If the expected event is expired, a red label "Expired" will show up at the table view.
//
//
//6. Food Section,
//
//1. The first screen users will see is all the Food outlets with name image on a table view.
//2. After select one outlet, extra information will show up in an view controller including building, description, direction button, open hours, and Service.
//3. Right now only two outlets have menu available, I wish University of Waterloo will update its API so users can see the menus from all outlets.(let's just hope)
//
//There are also some extra features not mentioned in ReadMe, you are welcome to explore it by yourself and please let me if there is a bug or something not working appropriate.
//


