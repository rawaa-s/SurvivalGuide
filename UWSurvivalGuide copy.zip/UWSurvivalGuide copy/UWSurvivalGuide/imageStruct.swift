//
//  imageStruct.swift
//  UWSurvivalGuide
//
//  Created by Xiaochao Luo on 2016-07-03.
//  Copyright © 2016 Xiaochao Luo. All rights reserved.
//

import Foundation
import UIKit



struct imageStruct {
    
    var theIamge: UIImage!
    
    
}