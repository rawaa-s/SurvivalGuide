

UWSurvivleGuide Features


In order to make students to have a more convienent environment to access some of the informations, I decided to make this app.

In this project, there 4 main sections, which are News, Event, Parking and Food. All the data is obtained from our school's API.


1. News

In the news section, users can see the news posted on our school's website without use the browser and load extra datas. Every page in the news section is core data persistent. When users go to the next page, the previous page is automatically cleaned from the Core Data. The image is using imageCache to retain persistent.

2. Event

In the Event section, I've created an "expected events" section, where users can mark the events they like in all events section and these events will show up in the "expected events" section. There is also a expire warning in each view controllers in Event.


3. Parking

Parking has 5 different sections, monitored, visitor, permit, meter and building.

As it stated, monitored is for the parkings lots that can be monitored with their capacity and parkign filled rate.
Visitor is for visitor parkings lots, and so on.

In each section, users can locate the parking lot on map and find a route to it. They can also find the building first, and show all the different kind of parking lots avaialbe around the building

4. Food

In the food section, user can find almost all of the food outlets on it(some of them is not available on the api). There are some special notes and open hours, locations(user can show it on map), services, etc.

Thanks for reading, hope you can enjoy the app and have a better life experience on UW's campus.


