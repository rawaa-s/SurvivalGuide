//
//  FoodOutletsTableViewCell.swift
//  UWSurvivalGuide
//
//  Created by Rawaa alshafeai
//  Copyright © Rawaa alshafeai. All rights reserved.
//

import Foundation
import UIKit

class FoodOutletsTableViewCell: UITableViewCell {

    @IBOutlet weak var outletsName: UILabel!
    @IBOutlet weak var outletsIcon: UIImageView!
    
    
    
    
    
}
